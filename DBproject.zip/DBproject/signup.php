<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "your_database_name";

    $name = $_POST["name"];
    $login_id = $_POST["login_id"];
    $password = $_POST["password"];
    $phone_number = $_POST["phone_number"];

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO users (name, login_id, password, phone_number) VALUES ('$name', '$login_id', '$password', '$phone_number')";

    if ($conn->query($sql) === TRUE) {
        // 회원가입 성공 시 main.html로 이동
        header("Location: main.html");
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
